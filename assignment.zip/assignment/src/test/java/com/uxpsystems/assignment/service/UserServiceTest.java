package com.uxpsystems.assignment.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import com.uxpsystems.assignment.dao.UserDao;
import com.uxpsystems.assignment.model.User;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
	@Mock
	private UserDao daoMock;

	@InjectMocks
	private UserService service = new UserServiceImpl();

	@Captor
	private ArgumentCaptor<User> userArgument;

	@Before
	public void setUp() throws Exception {

		MockitoAnnotations.initMocks(this);
	}

	//Here is an easy fix that will ensure errors appear in the correct test method(Stackoverflow)
	@After
	public void validate() {
	    Mockito.validateMockitoUsage();
	}
	
	@Test
	public void test_getAllUsers() {
		User dummy = new User(1L, "Dummy", "Inactive");
		User dummy1 = new User(2L, "Dummy", "Inactive");
		Mockito.when(daoMock.getAllUsers()).thenReturn(Arrays.asList(dummy, dummy1));
		List<User> users = service.getAllUsers();
		assertNotNull(users);
		assertEquals(2, users.size());
	}

	@Test
	public void test_findById() {
		User dummy = new User(1L, "Dummy", "Inactive");
		Mockito.when(daoMock.findById(1L)).thenReturn(dummy);

		User user = service.findById(1L);
		assertNotNull(user);
		assertEquals(1L, dummy.getId());
		assertEquals("Dummy", dummy.getUsername());
		assertEquals("Inactive", dummy.getStatus());
	}

	@Test
	public void test_isUserExist() {
		User user = new User(1L, "Dummy", "Active");
		Mockito.when(daoMock.findById(user.getId())).thenReturn(user);
		boolean exist = service.isUserExist(user);
		assertNotNull(exist);
		assertEquals(true, exist);

	}

	@Test
	public void test_saveUser() {
		User user = new User(1L, "Dummy", "Inactive");
		service.saveUser(user);
		// captures the argument which was passed in to addUser method.
		Mockito.verify(daoMock).addUser(userArgument.capture());

	}

	@Test
	public void test_updateUser() {
		User user = new User(1L, "Dummy", "Inactive");
		service.updateUser(user);
		// captures the argument which was passed in to addUser method.
		Mockito.verify(daoMock).updateUser(userArgument.capture());

	}

	@Test
	public void test_deleteUser() {
		User user = new User(1L, "Dummy", "Inactive");
		service.deleteUserById(user.getId());
		Mockito.verify(daoMock).deleteUserById(user.getId());
		// make sure a token is assigned by the register method before saving.
		/*assertEquals(userArgument.getValue().getId(),1L);*/
	}
}
