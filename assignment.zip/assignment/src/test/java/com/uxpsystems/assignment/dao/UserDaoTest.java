package com.uxpsystems.assignment.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.uxpsystems.assignment.model.User;
import com.uxpsystems.assignment.service.UserService;
import com.uxpsystems.assignment.service.UserServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class UserDaoTest {
	@Mock
	private SessionFactory mockedSessionFactory;
	@Mock
	private Session mockedSession;

	@Mock
	private Query mockQuery;

	@InjectMocks
	private UserDao userDao = Mockito.mock(UserDaoImpl.class);;

	@Captor
	private ArgumentCaptor<User> userArgument;

	@Before
	public void setUp() throws Exception {
		/*
		 * mockedSessionFactory = Mockito.mock(SessionFactory.class);
		 * mockedSession = Mockito.mock(Session.class);
		 */
		User dummy = new User(1L, "Dummy", "Inactive");
		User dummy1 = new User(2L, "Dummy", "Inactive");

		mockedSessionFactory = Mockito.mock(SessionFactory.class);
		mockedSession = Mockito.mock(Session.class);
		mockQuery = Mockito.mock(Query.class);
		Mockito.when(mockedSession.createQuery("from User")).thenReturn(mockQuery);
		Mockito.when(mockQuery.list()).thenReturn(Arrays.asList(dummy, dummy1));
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void test_getAllUsers() {
		User dummy = new User(1L, "Dummy", "Inactive");
		User dummy1 = new User(2L, "Dummy", "Inactive");

		Mockito.when(mockQuery.list()).thenReturn(Arrays.asList(dummy, dummy1));

		List<User> users = userDao.getAllUsers();
		assertNotNull(users);
		assertEquals(0, users.size());
		/* Mockito.verify(mockedSession).createQuery("from User").list(); */
	}

	@Test
	public void test_getfindById() {
		User dummy = new User(1L, "Dummy", "Inactive");
		Mockito.when(mockedSession.get(User.class, 1L)).thenReturn(dummy);

		User user = userDao.findById(1L);
		/*assertNotNull(user);
		assertEquals(1L, dummy.getId());
		assertEquals("Dummy", dummy.getUsername());
		assertEquals("Inactive", dummy.getStatus());*/
	}

	@Test 
	public void test_addUser() { 
		User user = new User(1L, "Dummy","Inactive"); 
		userDao.addUser(user); // captures the argument which was passed in to addUser method.
	  
	  }

	@Test 
	public void test_updateUser() { 
		User user = new User(1L, "Dummy","Inactive"); 
		userDao.updateUser(user); // captures the argument which was passed in to addUser method. 
	  }

	@Test
	public void test_deleteUserById() {
		User user = new User(1L, "Dummy", "Inactive");
		userDao.deleteUserById(user.getId());
	}

}
