package com.uxpsystems.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uxpsystems.assignment.dao.UserDao;
import com.uxpsystems.assignment.model.User;

@Service
@Transactional
public class UserServiceImpl implements UserService {
    @Autowired
	private UserDao userDao;
	
	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userDao.getAllUsers();
	}

	@Override
	public User findById(long id) {
		// TODO Auto-generated method stub
		return userDao.findById(id);
	}

	@Override
	public boolean isUserExist(User user) {
		// TODO Auto-generated method stub
		long id =user.getId();
		if(findById(id)==null)
			return false;
		return true;
	}

	@Override
	public void saveUser(User user) {
		// TODO Auto-generated method stub
		 userDao.addUser(user);
	}

	@Override
	public void updateUser(User currentUser) {
		// TODO Auto-generated method stub
		userDao.updateUser(currentUser);
	}

	@Override
	public void deleteUserById(long id) {
		// TODO Auto-generated method stub
		userDao.deleteUserById(id);
	}

}
