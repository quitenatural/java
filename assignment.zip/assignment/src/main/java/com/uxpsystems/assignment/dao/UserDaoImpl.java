package com.uxpsystems.assignment.dao;

import java.util.List;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.uxpsystems.assignment.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("from User").list();
	}

	@Override
	public User findById(long id) {
		// TODO Auto-generated method stub
		return (User) sessionFactory.getCurrentSession().get(User.class, id);
	}

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(user);
	}

	@Override
	public void updateUser(User currentUser) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().update(currentUser);
	}

	@Override
	public void deleteUserById(long id) {
		// TODO Auto-generated method stub
		try{
		User user=sessionFactory.getCurrentSession().load(User.class, id);
		if(null!=user)
			this.sessionFactory.getCurrentSession().delete(user);
		}
		catch(ObjectNotFoundException ob)
		{
			System.out.println("User with id: "+id+" not found for deletion.");
		}
	}

}
