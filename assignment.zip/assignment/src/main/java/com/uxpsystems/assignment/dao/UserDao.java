package com.uxpsystems.assignment.dao;

import java.util.List;

import com.uxpsystems.assignment.model.User;

public interface UserDao {

	List<User> getAllUsers();

	User findById(long id);

	void addUser(User user);

	void updateUser(User currentUser);

	void deleteUserById(long id);

}
