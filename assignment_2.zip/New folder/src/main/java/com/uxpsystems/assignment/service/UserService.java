package com.uxpsystems.assignment.service;

import java.util.List;

import org.springframework.security.access.annotation.Secured;

import com.uxpsystems.assignment.model.User;

public interface UserService {
	@Secured({ "ROLE_ADMIN" })
	public List<User> getAllUsers();

	@Secured({ "ROLE_USER", "ROLE_ADMIN" })
	public User findById(long id);

	@Secured({ "ROLE_USER", "ROLE_ADMIN" })
	public boolean isUserExist(User user);

	@Secured({ "ROLE_USER", "ROLE_ADMIN" })
	public void saveUser(User user);

	@Secured({ "ROLE_ADMIN" })
	public void updateUser(User currentUser);

	@Secured({ "ROLE_ADMIN" })
	public void deleteUserById(long id);

	@Secured({ "ROLE_USER", "ROLE_ADMIN" })
	public boolean isStatusValid(User user);

}
