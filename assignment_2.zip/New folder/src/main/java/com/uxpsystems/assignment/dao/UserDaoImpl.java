package com.uxpsystems.assignment.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.uxpsystems.assignment.model.User;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("from User")
				.list();
	}

	@Override
	public User findById(long id) {
		// TODO Auto-generated method stub
		return (User) sessionFactory.getCurrentSession().get(User.class, id);
	}

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(user);
	}

	@Override
	public void updateUser(User currentUser) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().update(currentUser);
	}

	@Override
	public void deleteUserById(long id) {
		// TODO Auto-generated method stub
		try {
			User user = sessionFactory.getCurrentSession().load(User.class, id);
			if (null != user)
				this.sessionFactory.getCurrentSession().delete(user);
		} catch (ObjectNotFoundException ob) {
			System.out.println("User with id: " + id
					+ " not found for deletion.");
		}
	}

	@Override
	public User findByUserName(String uname) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		User user=null;
		try {
			Criteria criteria = session.createCriteria(User.class);
			criteria.add(Restrictions.eq("username", uname));
			user = (User) criteria.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		return user;
	}
}
