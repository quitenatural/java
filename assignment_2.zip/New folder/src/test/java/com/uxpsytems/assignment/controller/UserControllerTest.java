/*package com.uxpsytems.assignment.controller;

import java.util.Arrays;
import java.util.List;

import org.hibernate.StaleObjectStateException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uxpsystems.assignment.dao.UserDao;
import com.uxpsystems.assignment.model.User;
import com.uxpsystems.assignment.service.UserService;
import static java.util.Collections.singletonList;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.core.Is.is;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({"classpath:spring-servlet.xml","classpath:web.xml"})
public class UserControllerTest {

	@Autowired
	private WebApplicationContext wac;

	private MockMvc mockMvc;

	@Mock
	private UserDao daoMock;

	@Autowired
	private UserService mockService;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}

	@Test
	public void test_listAllUsers() throws Exception {
		
		 * try {
		 * this.mockMvc.perform(get("/user/").with(user("prat").password("6656")
		 * ).contentType(APPLICATION_JSON)) .andExpect(status().is(403)); }
		 * catch (AccessDeniedException d) { // do nothing }
		 
	}

	@Test
	public void test_getUser() throws Exception {
		this.mockMvc.perform(get("/user/1").with(user("prat").password("6656")).contentType(APPLICATION_JSON))
				.andExpect(status().isNotFound());
	}

	@Test
	public void test_createUser() throws Exception {
		
		 * User user = new User(1L, "Dummy", "Inactive"); ObjectMapper mapper =
		 * new ObjectMapper(); String value = mapper.writeValueAsString(user);
		 * try {
		 * Mockito.when(mockService.saveUser(value)).thenReturn(HttpStatus.
		 * CREATED); this.mockMvc.perform(post("/user/") .with(user("prat")
		 * .password("6656")) .contentType(APPLICATION_JSON).content(value))
		 * .andExpect(status().isOk()); } catch(StaleObjectStateException
		 * staleEx) { //do nothing }
		 
	}

	@Test
	public void test_updateUser() throws Exception {
	}

	@Test
	public void test_deleteUser() throws Exception {
	}
}
*/