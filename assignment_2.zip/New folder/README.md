#Uxp Systems Assignment

Assignment is a restful web application project performing all the CRUD operations on the entity USER.


# Features
1) The project has used Spring Framework, Spring MVC, Spring Security  and many other frameworks.
2) The project has implemented MVC design structure. 
3) The project implements BASIC AUTH for security and the method level security has also been provided using Spring Security.
4) Inbuild H2 database has been used for storing data.
5) Jetty-Maven plugin has been used to embed the server to the application and run the application on the go.
 

# Config
1) application.properties (/assignment/src/main/resources/application.properties): This file is loaded by spring-servlet.xml on intialisation for loading H2 database and Hibernate related properties.
2) spring-servlet.xml (/assignment/src/main/webapp/WEB-INF/spring-servlet.xml) : This file loads during startup of webapp and creates all the beans for datasource, hibernate etc.
3) web.xml (/assignment/src/main/webapp/WEB-INF/web.xml): this files specifies the location of spring-servlet.xml and inserts DelegatingFilterProxy for intercepting the request for authentication purposes. 

# Check Out and Build from Source

1) Clone the repository from GitHub:
 $ git clone git://github.com/SpringSource/greenhouse.git

2) Navigate into the cloned repository directory:
 $ cd greenhouse

3) The project uses Maven to build:
 $ mvn clean install
 
 
# Running from the Command Line
 
By default, the app will run in 'embedded' mode which does not require any external setup. The Jetty Maven plugin is configured for you in the POM file.
 1) Launch Tomcat from the command line:
 $ mvn jetty:run 

 2) Access the deployed webapp at
  http://localhost:9090/assignment
 

# IDE Support
If you would like to build and run from a Maven/Java Dynamic Web-project-capable IDE, such as Eclipse/SpringSource Tool Suite, you may simply import "as a Maven Project" into your IDE and 
deploy the project to your IDE's embedded servlet container.
 
## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.